2016 - CS308  Group 8 : Smart Luggage
================================================ 
 
Group Info: 
------------ 
Aakash Deshpande 120050005
Royal Jain 120050014
Depen Morwani 120050015
Paramdeep Singh 120050085

Project Description 
------------------- 
Frequent travellers may have to carry precious luggage over long distances. In many cases, the luggage of the client is hidden from sight. For example, when the client is travelling by train and has an upper berth, or when travelling by a bus with a separate cargo hold. In crowded areas, the luggage is susceptible to theft or improper handling. The device aims to protect the client from such issues. 
 
Technologies Used 
------------------- 
 
+   Embedded C 
+   Android 
+   Specialized Hardware  
 
Installation Instructions 
========================= 
Install Android Studio.
 
Demonstration Video 
=========================  
TIVA screencast - https://youtu.be/FxKa67gEkOs
Android screencast - https://youtu.be/w0OcVFhkeQU

References 
=========== 
 
https://www.cse.iitb.ac.in/~erts/html_pages/Resources/Tiva/TM4C123G_LaunchPad_Workshop_Workbook.pdf 
https://e2e.ti.com/support/microcontrollers/tiva_arm/ 
